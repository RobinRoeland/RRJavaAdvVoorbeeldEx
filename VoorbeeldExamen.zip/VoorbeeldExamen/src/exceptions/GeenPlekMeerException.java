package exceptions;

import model.Schip;

public class GeenPlekMeerException extends Exception{
    public GeenPlekMeerException(Schip schip) {
        super("Aanmeren geannuleerd voor " + schip.getClass().getSimpleName() + " " + schip.naam + ": Er is geen plek meer!");
    }
}

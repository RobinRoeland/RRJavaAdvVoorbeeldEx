package exceptions;

import model.Schip;

public class SchipNietGevondenException  extends Exception{
    public SchipNietGevondenException(Schip schip) {
        super("Afmeren mislukt: " + schip.getClass().getSimpleName() + " " + schip.naam + "ligt niet in onze haven!");
    }
}

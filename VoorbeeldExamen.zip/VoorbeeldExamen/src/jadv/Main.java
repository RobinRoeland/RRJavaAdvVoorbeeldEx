package jadv;


import model.*;
import exceptions.*;

import java.util.ArrayList;

public class Main {
    public static void main(String[] args){
        Haven haven = new Haven();
        ArrayList<Schip> aankomendeSchepen = new ArrayList<Schip>();
        ArrayList<Schip> vertrekSchepen = new ArrayList<Schip>();

        Vrachtschip schip1 = new Vrachtschip("HelloWorld",45,20);
        Zeilboot bootje = new Zeilboot("NietCreatiefGenoeg", 25, 1);
        Motorboot bootje2 = new Motorboot("booootje", 10);

        aankomendeSchepen.add(schip1);
        aankomendeSchepen.add(bootje);

        for (Schip schip : aankomendeSchepen) {
            try {
                haven.aanmeren(schip);
            } catch (GeenPlekMeerException gpme) {
                System.out.println(gpme.getMessage());
            }
            aankomendeSchepen.remove(schip);
        }

        System.out.println(haven.schepen);

        vertrekSchepen.add(schip1);
        vertrekSchepen.add(bootje2);

        for (Schip schip : vertrekSchepen) {
            try {
                haven.afmeren(schip);
            } catch (SchipNietGevondenException snge) {
                System.out.println(snge.getMessage());
            }
            vertrekSchepen.remove(schip);
        }
    }
}

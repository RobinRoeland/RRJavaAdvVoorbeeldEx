package model;

import exceptions.GeenPlekMeerException;
import exceptions.SchipNietGevondenException;

import java.util.ArrayList;

public class Haven implements Loodsbaar {
    private final int maximumLengte = 150;
    private int lengteSchepen = 0;
    public  ArrayList<Schip> schepen = new ArrayList<Schip>();

    @Override
    public void loods(Schip schip) {
        System.out.println(schip.getClass().getSimpleName() + " " + schip.naam + " loodsen...");
    }

    public void aanmeren(Schip schip) throws GeenPlekMeerException {
        if (lengteSchepen + schip.lengte <= maximumLengte){
            System.out.println("Aanmeren van " + schip.toString() + ".");
            if(schip.getClass().getSimpleName().equals("Vrachtschip"))
                loods(schip);
            lengteSchepen += schip.lengte;
            schepen.add(schip);
        }
        else
            throw new GeenPlekMeerException(schip);
    }

    public void afmeren(Schip schip) throws SchipNietGevondenException {
        if (schepen.contains(schip)) {
            schepen.remove(schip);
            lengteSchepen -= schip.lengte;
            System.out.println(schip.getClass().getSimpleName() + " " + schip.naam + " vaart weg");
        }
        else
            throw new SchipNietGevondenException(schip);
    }
}

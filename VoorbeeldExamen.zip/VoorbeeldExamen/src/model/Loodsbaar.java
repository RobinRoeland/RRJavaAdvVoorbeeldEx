package model;

public interface Loodsbaar {
    public void loods(Schip schip);
}

package model;

public class Motorboot extends Schip{
    public Motorboot(String naam, int lengte){
        super(naam, lengte);
    }
}

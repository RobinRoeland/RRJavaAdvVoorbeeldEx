package model;

public abstract class Schip {
    public String naam;
    protected int lengte;

    public Schip(String naam, int lengte){
        this.naam = naam;
        this.lengte = lengte;
    }
}

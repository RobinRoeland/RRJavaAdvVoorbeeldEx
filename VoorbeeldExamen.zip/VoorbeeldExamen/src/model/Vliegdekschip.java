package model;

public class Vliegdekschip extends Schip{
    private int vliegtuigVermogen;

    public Vliegdekschip(String naam, int lengte, int vliegtuigVermogen){
        super(naam, lengte);
        this.vliegtuigVermogen = vliegtuigVermogen;
    }

    public String toString(){
        return "[Vrachtschip: " + naam + ", lengte: " + lengte + ", laadVermogen: " + vliegtuigVermogen + " vliegtuigen]";
    }
}

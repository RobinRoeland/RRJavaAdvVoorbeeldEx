package model;
import model.Loodsbaar;

public class Vrachtschip extends Schip{
    private int laadVermogen;

    public Vrachtschip(String naam, int lengte, int laadVermogen){
        super(naam, lengte);
        this.laadVermogen = laadVermogen;
    }

    public String toString(){
        return "[Vrachtschip: " + naam + ", lengte: " + lengte + ", laadVermogen: " + laadVermogen + "ton]";
    }


}

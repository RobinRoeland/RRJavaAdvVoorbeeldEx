package model;

public class Zeilboot extends Schip{
    private int aantalMasten;

    public Zeilboot(String naam, int lengte, int aantalMasten){
        super(naam, lengte);
        this.aantalMasten = aantalMasten;
    }

    public String toString(){
        return "[Zeilboot: " + naam + ", " + lengte + ", " + aantalMasten + " mast(en)]";
    }
}
